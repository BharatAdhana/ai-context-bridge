'use strict';

const path = require('path');
const fsp = require('fs/promises');

const {
  bootstrapProjectAnalysis,
  createDefaultChangelog,
  createDefaultState,
  detectProjectMetadata,
  ensureContextDirectory,
  getContextPaths,
  readJsonFile,
  renderTemplate,
  updateRuntimeConfig,
  writeJsonAtomic,
  writeTextAtomic
} = require('./stateManager');
const { ensureGitInitialized } = require('./gitSync');

async function initProject(projectRoot, options) {
  const settings = Object.assign(
    {
      logger: null,
      force: false,
      requestPublicSyncConsent: false,
      promptForPublicSyncConsent: null
    },
    options
  );
  const logger = settings.logger;
  const contextDir = await ensureContextDirectory(projectRoot);
  const paths = getContextPaths(projectRoot);
  const metadata = detectProjectMetadata(projectRoot);
  const templateDir = path.join(__dirname, '..', 'templates');
  const stateTemplate = await fsp.readFile(path.join(templateDir, 'state.template.json'), 'utf8');
  const changelogTemplate = await fsp.readFile(
    path.join(templateDir, 'changelog.template.json'),
    'utf8'
  );
  const brainTemplate = await fsp.readFile(path.join(templateDir, 'brain.template.txt'), 'utf8');
  const contextTemplate = await fsp.readFile(path.join(templateDir, 'context.template.md'), 'utf8');
  const existingConfig = await readJsonFile(paths.configFile, null);
  const existingState = await readJsonFile(paths.stateFile, null);
  const existingChangelog = await readJsonFile(paths.changelogFile, null);
  const templateState = JSON.parse(stateTemplate);
  const templateChangelog = JSON.parse(changelogTemplate);
  let enableGitSync = false;
  const bootstrapState = createDefaultState(projectRoot);
  const bootstrapAnalysis = bootstrapProjectAnalysis(projectRoot);

  const initialState = Object.assign({}, templateState, existingState || bootstrapState, {
    project: metadata.project,
    version: metadata.version,
    ai_summary: bootstrapState.ai_summary,
    tech_stack: bootstrapAnalysis.techStack,
    architecture_patterns: bootstrapAnalysis.architecturePatterns,
    implementation_details: bootstrapAnalysis.implementationDetails,
    current_stage: bootstrapState.current_stage,
    key_features: bootstrapState.key_features,
    known_issues: bootstrapState.known_issues,
    next_steps: bootstrapState.next_steps
  });

  const initialContext = renderTemplate(contextTemplate, {
    PROJECT_NAME: metadata.project,
    PROJECT_VERSION: metadata.version,
    STACK_LABEL: metadata.stackLabel,
    PACKAGE_MANAGER: metadata.packageManager
  });
  const shouldWriteBrain = settings.force || !(await fileExists(paths.brainFile));
  const shouldWriteContext = settings.force || !(await fileExists(paths.contextFile));

  await writeJsonAtomic(paths.stateFile, initialState);
  await writeJsonAtomic(paths.changelogFile, existingChangelog || templateChangelog || createDefaultChangelog());

  if (shouldWriteBrain) {
    await writeTextAtomic(paths.brainFile, brainTemplate);
  }

  if (shouldWriteContext) {
    await writeTextAtomic(paths.contextFile, initialContext);
  }

  if (!existingConfig && settings.requestPublicSyncConsent) {
    enableGitSync = await requestPublicSyncConsent(
      logger,
      settings.promptForPublicSyncConsent
    );
  }

  await updateRuntimeConfig(projectRoot, existingConfig ? null : {
    gitSync: {
      enabled: enableGitSync
    }
  });

  await ensureGitInitialized(projectRoot, logger);

  if (logger) {
    logger.info(`Initialized AI context in ${contextDir}`);
  }

  return {
    contextDir,
    metadata
  };
}

async function requestPublicSyncConsent(logger, promptForPublicSyncConsent) {
  if (logger) {
    logger.warn('This tool can make parts of your project publicly accessible for AI tools.');
    logger.info('It will:');
    logger.info('* Track project changes');
    logger.info('* Generate AI-readable context');
    logger.info('* Optionally sync to GitHub');
    logger.info('* Create a PUBLIC URL accessible by AI systems');
    logger.warn('WARNING:');
    logger.warn('Anyone with the URL can read this data.');
  }

  if (typeof promptForPublicSyncConsent !== 'function') {
    if (logger) {
      logger.info('GitHub sync will remain disabled until you explicitly enable it.');
    }

    return false;
  }

  return Boolean(await promptForPublicSyncConsent());
}

async function fileExists(filePath) {
  try {
    await fsp.access(filePath);
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = {
  initProject
};
